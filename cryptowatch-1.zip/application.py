from flask import Flask, render_template, request, redirect, send_file, url_for, session
from datetime import datetime
import re
import pymysql
import rds_credentials as rds
import s3read as s3r 
import requests
import aws_credentials as aws_cred
from boto3 import resource
import io
import base64
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns


#app
application = Flask(__name__)


#It's used to encrypt the session cookie so that you can be reasonably (but not 100%) sure the cookie isn't a fake one,
application.secret_key = 'your secret key'

df1=s3r.get_eth_coin()
df2=s3r.get_aave_coin()
df3=s3r.get_bnb_coin()
df4=s3r.get_bit_coin()
df5=s3r.get_ada_coin()
df6=s3r.get_sol_coin()
aws_id = aws_cred.aws_access_key_id
aws_secret = aws_cred.aws_secret_access_key
aws_token=aws_cred.aws_session_token


conn = pymysql.connect(
        host= rds.host, #endpoint link
        port = rds.port, # 3306
        user = rds.user, # admin
        password = rds.password, #Vamsi243        
        )


resource = resource(
   service_name='dynamodb',
   aws_access_key_id =aws_id ,
   aws_secret_access_key = aws_secret,
   region_name='us-east-1',
   aws_session_token=aws_token
)

table = resource.Table('fav_coins')

  
@application.route('/')
@application.route('/login', methods =['GET', 'POST'])
def login():
    msg = ''
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form:
        username = request.form['username']
        password = request.form['password']
        cur = conn.cursor()
        cur.execute('SELECT * FROM user_db.user_details WHERE username = %s AND password = %s', (username, password))
        account = cur.fetchone()
        if account:
            session['loggedin'] = True
            session['username'] = account[1]
            msg = 'Logged in successfully !'
            return render_template('index.html', msg=msg)
        else:
            msg = 'Incorrect username / password !'
    return render_template('login.html', msg = msg)
  

@application.route('/favourites', methods =['GET','POST'])
def favourites():
    msg=''
    if request.method == 'POST' :
        username=session['username']
        coins =request.form['coins[]']
        with table.batch_writer() as batch:
            batch.put_item(Item={"username":username,"coins" : coins } )
        print(batch)
        print(coins)
        msg='Added to favourites successfully'
    return render_template('favourites.html', msg = msg)


@application.route('/index')
def index():
    return render_template('index.html')
    

@application.route('/logout')
def logout():
    session.pop('loggedin', None)
    session.pop('username', None)
    return redirect(url_for('login'))
  
@application.route('/register', methods =['GET', 'POST'])
def register():
    msg = ''
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form and 'email' in request.form :
        name = request.form['name']
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']
        phone = request.form['phone']
        cur =conn.cursor()
        cur.execute('SELECT * FROM user_db.user_details WHERE username = %s', (username ))
        account = cur.fetchone()
        if account:
            msg = 'Account already exists !'
        elif not re.match(r'[^@]+@[^@]+\.[^@]+', email):
            msg = 'Invalid email address !'
        elif not re.match(r'[A-Za-z0-9]+', username):
            msg = 'Username must contain only characters and numbers !'
        elif not username or not password or not email:
            msg = 'Please fill out the form !'
        else:
            cur.execute('INSERT INTO user_db.user_details VALUES (%s, % s, % s, % s,%s)', (name,username,email, password, phone))
            conn.commit()
            msg = 'You have successfully registered !'
            #json value sent to lambda function via api
            dictionary = {"Message":"User added successfully"}
            # aws http API gatway url used to trigger lambda function
            response   = requests.post('https://eg6lwxfh72.execute-api.us-east-1.amazonaws.com/UsercountSNS', json=dictionary)
    elif request.method == 'POST':
        msg = 'Please fill out the form !'
    return render_template('register.html', msg = msg)


@application.route('/visualize1')
def visualize1():
    fig1,ax1=plt.subplots(figsize=(6,6))
    ax1=sns.set(style="darkgrid")
    sns.lineplot(data=df1, x="Date", y="Close")
    canvas=FigureCanvas(fig1)
    img1 = io.BytesIO()
    fig1.savefig(img1)
    img1.seek(0)
    return send_file (img1,mimetype='img/png')


@application.route('/visualize2')
def visualize2():
    fig2,ax2=plt.subplots(figsize=(6,6))
    ax2=sns.set(style="darkgrid")
    sns.lineplot(data=df2, x="Date", y="Close")
    canvas=FigureCanvas(fig2)
    img2 = io.BytesIO()
    fig2.savefig(img2)
    img2.seek(0)
    return send_file (img2,mimetype='img/png')



@application.route('/visualize3')
def visualize3():
    fig3,ax3=plt.subplots(figsize=(6,6))
    ax3=sns.set(style="darkgrid")
    sns.lineplot(data=df3, x="Date", y="Close")
    canvas=FigureCanvas(fig3)
    img3 = io.BytesIO()
    fig3.savefig(img3)
    img3.seek(0)
    return send_file (img3,mimetype='img/png')



@application.route('/visualize4')
def visualize4():
    fig4,ax4=plt.subplots(figsize=(6,6))
    ax4=sns.set(style="darkgrid")
    sns.lineplot(data=df4, x="Date", y="High")
    canvas=FigureCanvas(fig4)
    img4 = io.BytesIO()
    fig4.savefig(img4)
    img4.seek(0)
    return send_file (img4,mimetype='img/png')


@application.route('/visualize5')
def visualize5():
    fig5,ax5=plt.subplots(figsize=(6,6))
    ax5=sns.set(style="darkgrid")
    sns.lineplot(data=df5, x="Date", y="Close")
    canvas=FigureCanvas(fig5)
    img5 = io.BytesIO()
    fig5.savefig(img5)
    img5.seek(0)
    return send_file (img5,mimetype='img/png')


@application.route('/visualize6')
def visualize6():
    fig,ax=plt.subplots(figsize=(6,6))
    ax=sns.set(style="darkgrid")
    sns.lineplot(data=df6, x="Date", y="High")
    canvas=FigureCanvas(fig)
    img = io.BytesIO()
    fig.savefig(img)
    img.seek(0)
    return send_file (img,mimetype='img/png')

if __name__ == '__main__':
    application.run()