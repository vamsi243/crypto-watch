
host= 'database-1.ccn4dbaiqgls.us-east-1.rds.amazonaws.com'
port = 3306
user = 'admin'
password = 'Vamsi243'
