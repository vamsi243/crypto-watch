import boto3
from boto3 import resource
import io
import pandas as pd
import json
import aws_credentials as aws_cred
aws_id = aws_cred.aws_access_key_id
aws_secret = aws_cred.aws_secret_access_key
aws_token=aws_cred.aws_session_token

resource = resource(
   service_name='dynamodb',
   aws_access_key_id =aws_id ,
   aws_secret_access_key = aws_secret,
   region_name='us-east-1',
   aws_session_token=aws_token
)
