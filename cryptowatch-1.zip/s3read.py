import boto3
import io
import pandas as pd
import json
import aws_credentials as aws_cred
aws_id = aws_cred.aws_access_key_id
aws_secret = aws_cred.aws_secret_access_key
aws_token=aws_cred.aws_session_token
bucket_name = 'coin.eth'
object_key1='coin_Ethereum1.xlsx'
object_key2='coin_Aave1.xlsx'
object_key3='coin_BinanceCoin1.xlsx'
object_key4='coin_Bitcoin1.xlsx'
object_key5='coin_Cardano1.xlsx'
object_key6='coin_Solana1.xlsx'

s3 = boto3.client(
    service_name='s3',
    region_name='us-east-1',
    aws_access_key_id=aws_id,
    aws_secret_access_key=aws_secret,
    aws_session_token=aws_token
)

obj1 = s3.get_object(Bucket=bucket_name, Key=object_key1)
data1 = obj1['Body'].read()
df1 = pd.read_excel(io.BytesIO(data1))

obj2 = s3.get_object(Bucket=bucket_name, Key=object_key2)
data2 = obj2['Body'].read()
df2 = pd.read_excel(io.BytesIO(data2))

obj3 = s3.get_object(Bucket=bucket_name, Key=object_key3)
data3 = obj3['Body'].read()
df3 = pd.read_excel(io.BytesIO(data3))

obj4 = s3.get_object(Bucket=bucket_name, Key=object_key4)
data4 = obj4['Body'].read()
df4 = pd.read_excel(io.BytesIO(data4))

obj5 = s3.get_object(Bucket=bucket_name, Key=object_key5)
data5 = obj5['Body'].read()
df5 = pd.read_excel(io.BytesIO(data5))

obj6 = s3.get_object(Bucket=bucket_name, Key=object_key6)
data6 = obj6['Body'].read()
df6 = pd.read_excel(io.BytesIO(data6))


def get_eth_coin():    
    return df1

def get_aave_coin():    
    return df2

def get_bnb_coin():    
    return df3

def get_bit_coin():    
    return df4

def get_ada_coin():    
    return df5

def get_sol_coin():    
    return df6

